
package quirozmaria_classdiagram;

/**
 *
 * @author Quiroz Maria
 */
import java.util.List;

public class D {
    private F f; 
    private List<E> elementosE; 

    
}
