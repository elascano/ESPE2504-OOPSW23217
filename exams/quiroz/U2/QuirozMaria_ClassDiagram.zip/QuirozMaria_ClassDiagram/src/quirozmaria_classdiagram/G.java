
package quirozmaria_classdiagram;

/**
 *
 * @author Quiroz Maria
 */
public class G implements H {
    private J j; 

    public G(J j) {
        this.j = j;
    }

    @Override
    public void metodoH() {
        System.out.println("Implementación del método H en G");
    }
}
