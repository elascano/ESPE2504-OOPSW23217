
package quirozmaria_classdiagram;

/**
 *
 * @author Quiroz Maria
 */
import java.util.List;

public class A extends C {
    private List<A> relacionesA; 
    private A otraA; 

}