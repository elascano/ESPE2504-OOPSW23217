package quirozmaria_classdiagram;

/**
 *
 * @author Quiroz Maria
 */
public class J {
    
}
