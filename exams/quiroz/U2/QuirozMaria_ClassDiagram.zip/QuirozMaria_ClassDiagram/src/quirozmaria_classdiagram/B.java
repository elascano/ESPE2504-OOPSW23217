package quirozmaria_classdiagram;

/**
 *
 * @author Quiroz Maria
 */
import java.util.List;

public class B {
    private List<H> r; 

    
}
