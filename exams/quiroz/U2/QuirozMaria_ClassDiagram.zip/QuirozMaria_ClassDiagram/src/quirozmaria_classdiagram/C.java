
package quirozmaria_classdiagram;

/**
 *
 * @author Quiroz Maria
 */
import java.util.List;

public class C {
    private List<E> elementosE; 

    
}