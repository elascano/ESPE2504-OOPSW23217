import tkinter as tk
from tkinter import messagebox
from pymongo import MongoClient

MONGO_URI = "mongodb+srv://mlquiroz:<Mlqh2006>@cluster0.vpeg1ly.mongodb.net/?retryWrites=true&w=majority"
client = MongoClient(MONGO_URI)
db = client["ExamU2"]
collection = db["ExamU2"]


class Shoe:
    def __init__(self, id, name, size, price):
        self.id = id
        self.name = name
        self.size = size
        self.price = price

    def compute_discount(self):
        return self.price * 0.9

    def to_dict(self):
        return {
            "_id": self.id,
            "name": self.name,
            "size": self.size,
            "price": self.price
        }

    def __str__(self):
        return f"ID: {self.id}, Nombre: {self.name}, Talla: {self.size}, Precio: ${self.price:.2f}"


class ShoeModel:
    def add_shoe(self, shoe):
        if collection.find_one({"_id": shoe.id}):
            raise ValueError("ID ya existe en la base de datos.")
        collection.insert_one(shoe.to_dict())

    def get_all_shoes(self):
        shoes = []
        for doc in collection.find():
            shoes.append(Shoe(doc["_id"], doc["name"], doc["size"], doc["price"]))
        return shoes

    def get_shoe_by_id(self, id):
        doc = collection.find_one({"_id": id})
        if doc:
            return Shoe(doc["_id"], doc["name"], doc["size"], doc["price"])
        return None

    def update_shoe(self, id, name, size, price):
        result = collection.update_one(
            {"_id": id},
            {"$set": {"name": name, "size": size, "price": price}}
        )
        return result.modified_count > 0

    def delete_shoe(self, id):
        collection.delete_one({"_id": id})


class ShoeController:
    def __init__(self):
        self.model = ShoeModel()

    def create_shoe(self, id, name, size, price):
        shoe = Shoe(id, name, size, price)
        self.model.add_shoe(shoe)

    def list_shoes(self):
        return self.model.get_all_shoes()

    def find_shoe_by_id(self, id):
        return self.model.get_shoe_by_id(id)

    def update_shoe(self, id, name, size, price):
        return self.model.update_shoe(id, name, size, price)

    def delete_shoe(self, id):
        self.model.delete_shoe(id)


class ShoeView:
    def __init__(self, root):
        self.controller = ShoeController()
        self.root = root
        self.root.title("Shoes")

        tk.Label(root, text="ID").grid(row=0, column=0, padx=5, pady=5)
        tk.Label(root, text="Name").grid(row=1, column=0, padx=5, pady=5)
        tk.Label(root, text="Size").grid(row=2, column=0, padx=5, pady=5)
        tk.Label(root, text="Price").grid(row=3, column=0, padx=5, pady=5)

        self.id_entry = tk.Entry(root)
        self.name_entry = tk.Entry(root)
        self.size_entry = tk.Entry(root)
        self.price_entry = tk.Entry(root)

        self.id_entry.grid(row=0, column=1)
        self.name_entry.grid(row=1, column=1)
        self.size_entry.grid(row=2, column=1)
        self.price_entry.grid(row=3, column=1)

        tk.Button(root, text="Create", command=self.create_shoe).grid(row=4, column=0, pady=10)
        tk.Button(root, text="Show all", command=self.show_all).grid(row=4, column=1, pady=10)

        self.output = tk.Text(root, height=12, width=55)
        self.output.grid(row=5, column=0, columnspan=2, padx=5, pady=10)

    def create_shoe(self):
        try:
            id = int(self.id_entry.get())
            name = self.name_entry.get()
            size = float(self.size_entry.get())
            price = float(self.price_entry.get())
            self.controller.create_shoe(id, name, size, price)
            messagebox.showinfo("Succesful", "Shoes saved in MongoDB Atlas.")
            self.clear_fields()
        except ValueError as ve:
            messagebox.showerror("Error", str(ve))

    def show_all(self):
        shoes = self.controller.list_shoes()
        self.output.delete(1.0, tk.END)
        if not shoes:
            self.output.insert(tk.END, "There are not shoes registered.\n")
        else:
            for s in shoes:
                self.output.insert(tk.END, str(s) + "\n")

    def clear_fields(self):
        self.id_entry.delete(0, tk.END)
        self.name_entry.delete(0, tk.END)
        self.size_entry.delete(0, tk.END)
        self.price_entry.delete(0, tk.END)


if __name__ == "__main__":
    root = tk.Tk()
    app = ShoeView(root)
    root.mainloop()
