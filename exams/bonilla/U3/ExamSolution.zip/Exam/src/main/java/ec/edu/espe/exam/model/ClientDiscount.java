package ec.edu.espe.exam.model;

/**
 *
 * @author Bonilla David SoftCrafters
 */
public class ClientDiscount implements DiscountStrategy {

    @Override
    public double calculateDiscount(double basePrice, Client client) {
        if (client.isVip()) {
            return basePrice * 0.8; // 20% discount
        }
        return basePrice;
    }
}
