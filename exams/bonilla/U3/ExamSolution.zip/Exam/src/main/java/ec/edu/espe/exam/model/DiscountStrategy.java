package ec.edu.espe.exam.model;

/**
 *
 * @author David Bonilla SoftCrafters ESPE
 */
public interface DiscountStrategy {

    public abstract double calculateDiscount(double basePrice, Client client);
}
