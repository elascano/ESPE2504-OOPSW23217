package ec.edu.espe.exam.controller;

import ec.edu.espe.exam.model.Client;
import ec.edu.espe.exam.model.ClientDiscount;
import ec.edu.espe.exam.model.ClientWithoutDiscount;
import ec.edu.espe.exam.model.DiscountStrategy;
import ec.edu.espe.exam.model.LargePackage;
import ec.edu.espe.exam.model.MediumPackage;
import ec.edu.espe.exam.model.SmallPackage;
import ec.edu.espe.exam.model.Package;
import ec.edu.espe.exam.model.Shipment;
import ec.edu.espe.exam.view.FrmCreateShipment;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 *
 * @author Bonilla David SoftCrafters
 */
public class FrmCreateShipmentController implements ActionListener {

    private static FrmCreateShipmentController instance;
    private FrmCreateShipment frmCreateShipment;

    private DiscountStrategy discountStrategy;
    private Package pack;

    private FrmCreateShipmentController() {
        this.frmCreateShipment = FrmCreateShipment.getInstance();
        frmCreateShipment.getBtmProcessShipment().addActionListener(this);

    }

    public static FrmCreateShipmentController getInstance() {
        if (instance == null) {
            instance = new FrmCreateShipmentController();
        }
        return instance;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == frmCreateShipment.getBtmProcessShipment()) {

            int idClient = Integer.parseInt(frmCreateShipment.getTxtId().getText());
            String name = frmCreateShipment.getTxtName().getText();
            String phone = frmCreateShipment.getTxtPhone().getText();
            String email = frmCreateShipment.getTxtEmail().getText();
            String address = frmCreateShipment.getTxtAddress().getText();
            boolean vip = frmCreateShipment.getCbxVip().isSelected();
            String type = frmCreateShipment.getCmbType().getSelectedItem().toString();
            double weight = Double.parseDouble(frmCreateShipment.getTxtWeight().getText());
            double declaredValue = Double.parseDouble(frmCreateShipment.getTxtDeclaredValue().getText());
            String contentDescription = frmCreateShipment.getTxtDescription().getText();
            String trackingCode = frmCreateShipment.getTxtTrackingCode().getText();
            boolean fragile = frmCreateShipment.getCbxFragility().isSelected();
            double basePrice = Double.parseDouble(frmCreateShipment.getTxtBasePrice().getText());

            Client client = new Client(idClient, name, phone, email, address, vip);

            //Context of Template Method
            switch (type) {
                case "Small":
                    pack = new SmallPackage(type, weight, declaredValue, contentDescription, trackingCode, fragile, basePrice);
                    break;
                case "Medium":
                    pack = new MediumPackage(type, weight, declaredValue, contentDescription, trackingCode, fragile, basePrice);
                    break;
                case "Large":
                    pack = new LargePackage(type, weight, declaredValue, contentDescription, trackingCode, fragile, basePrice);
                    break;
            }

            Shipment shipment = new Shipment(client, pack);

            FileManagerShipments.saveShipmentMongoDB(shipment);

            StringBuilder sb = new StringBuilder();
            sb.append("=== Datos del Envío ===\n")
                    .append("Cliente:\n")
                    .append("ID: ").append(client.getIdClient()).append("\n")
                    .append("Nombre: ").append(client.getName()).append("\n")
                    .append("Teléfono: ").append(client.getPhone()).append("\n")
                    .append("Email: ").append(client.getEmail()).append("\n")
                    .append("Dirección: ").append(client.getAddress()).append("\n")
                    .append("VIP: ").append(client.isVip() ? "Sí" : "No").append("\n\n")
                    .append("Paquete:\n")
                    .append("Tipo: ").append(pack.getType()).append("\n")
                    .append("Peso: ").append(pack.getWeight()).append(" kg\n")
                    .append("Valor declarado: $").append(pack.getDeclaredValue()).append("\n")
                    .append("Descripción: ").append(pack.getContentDescription()).append("\n")
                    .append("Código de seguimiento: ").append(pack.getTrackingCode()).append("\n")
                    .append("Frágil: ").append(pack.isFragile() ? "Sí" : "No").append("\n")
                    .append("Precio base: $").append(pack.getBasePrice()).append("\n")
                    .append("Precio Final: $").append(shipment.getFinalPrice()).append("\n");

            javax.swing.JOptionPane.showMessageDialog(
                    frmCreateShipment,
                    sb.toString(),
                    "Resumen del Envío",
                    javax.swing.JOptionPane.INFORMATION_MESSAGE
            );

        }
    }
}
