package ec.edu.espe.exam.model;

/**
 *
 * @author Bonilla David SoftCrafters
 */
public class Shipment {

    private Client client;
    private Package pack;
    private double finalPrice;
    private DiscountStrategy discountStrategy;

    public Shipment(Client client, Package pack) {
        this.client = client;
        this.pack = pack;
        this.finalPrice = applyDiscount(client);
    }

    //Strategy
    private double applyDiscount(Client client) {
        if (client.isVip()) {
            discountStrategy = new ClientDiscount();
        } else {
            discountStrategy = new ClientWithoutDiscount();
        }

        return discountStrategy.calculateDiscount(pack.getBasePrice(), client);
    }

    public Client getClient() {
        return client;
    }

    public Package getPack() {
        return pack;
    }

    public double getFinalPrice() {
        return finalPrice;
    }

    public void process() {
        getPack().processShipping();
    }

    public void setClient(Client client) {
        this.client = client;
    }

    public void setPack(Package pack) {
        this.pack = pack;
    }

    public void setFinalPrice(double finalPrice) {
        this.finalPrice = finalPrice;
    }

}
