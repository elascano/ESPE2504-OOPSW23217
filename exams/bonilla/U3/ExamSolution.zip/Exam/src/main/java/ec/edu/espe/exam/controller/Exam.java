package ec.edu.espe.exam.controller;

import ec.edu.espe.exam.view.FrmCreateShipment;

/**
 *
 * @author Bonilla David Softcrafters
 */
public class Exam {

    public static void main(String[] args) {
        FrmCreateShipmentController.getInstance();
        FrmCreateShipment.getInstance().setVisible(true);
    }

}
