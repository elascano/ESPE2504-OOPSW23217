package ec.edu.espe.exam.model;

/**
 *
 * @author Bonilla David SoftCrafters
 */

public class ClientWithoutDiscount implements DiscountStrategy {

    @Override
    public double calculateDiscount(double basePrice, Client client) {
        if (!client.isVip()) {
            return basePrice * 1.5; // add tax
        }
        return basePrice;
    }
}
