package espe.edu.ec.classdiagram.model;

public class G {
    private double g;

    public double getG() {
        return g;
    }

    public void setG(double g) {
        this.g = g;
    }
}