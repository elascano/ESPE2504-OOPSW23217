package espe.edu.ec.classdiagram.model;

public class D extends C {
    private double z;

    public double getZ() {
        return z;
    }

    public void setZ(double z) {
        this.z = z;
    }
}
