package espe.edu.ec.classdiagram.model;

public class H {
    private double h;

    public double getH() {
        return h;
    }

    public void setH(double h) {
        this.h = h;
    }
}
