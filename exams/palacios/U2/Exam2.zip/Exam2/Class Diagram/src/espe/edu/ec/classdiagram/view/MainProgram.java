package espe.edu.ec.classdiagram.view;

import espe.edu.ec.classdiagram.model.*;

public class MainProgram {
    public static void main(String[] args) {
 
        A a = new A();
        a.setValue(0.1);

        B b = new B();
        b.setR(1.0);

        C c = new C();
        c.setX(0.3);
        c.setY(0.4);

        D d = new D();
        d.setZ(1.0);

        E e = new E();
        e.setE(0.5);

        F f = new F();
        f.setF(0.4);

        G g = new G();
        g.setG(0.0);

        J j = new J();
        j.setJ(0.0);

        H h = new H();
        h.setH(1.0);

        // Mostrar los valores de los objetos
        System.out.println("Valores de los objetos:");
        System.out.println("A: " + a.getValue());
        System.out.println("B: " + b.getR());
        System.out.println("C: x = " + c.getX() + ", y = " + c.getY());
        System.out.println("D: z = " + d.getZ());
        System.out.println("E: " + e.getE());
        System.out.println("F: " + f.getF());
        System.out.println("G: " + g.getG());
        System.out.println("J: " + j.getJ());
        System.out.println("H: " + h.getH());
    }
}
