package espe.edu.ec.classdiagram.model;

public class E extends A {
    private double e;

    public double getE() {
        return e;
    }

    public void setE(double e) {
        this.e = e;
    }
}
