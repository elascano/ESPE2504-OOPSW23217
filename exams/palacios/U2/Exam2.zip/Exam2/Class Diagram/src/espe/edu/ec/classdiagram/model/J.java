package espe.edu.ec.classdiagram.model;

public class J {
    private double j;

    public double getJ() {
        return j;
    }

    public void setJ(double j) {
        this.j = j;
    }
}