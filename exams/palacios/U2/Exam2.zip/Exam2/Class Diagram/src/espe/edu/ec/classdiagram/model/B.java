package espe.edu.ec.classdiagram.model;

public class B extends A {
    private double r;

    public double getR() {
        return r;
    }

    public void setR(double r) {
        this.r = r;
    }
}
