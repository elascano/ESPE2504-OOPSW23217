package espe.edu.ec.classdiagram.model;

public class A {
    private double value;

    public double getValue() {
        return value;
    }

    public void setValue(double value) {
        this.value = value;
    }
}
