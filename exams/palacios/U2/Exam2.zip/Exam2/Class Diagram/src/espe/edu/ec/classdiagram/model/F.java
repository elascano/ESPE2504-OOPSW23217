package espe.edu.ec.classdiagram.model;

public class F extends A {
    private double f;

    public double getF() {
        return f;
    }

    public void setF(double f) {
        this.f = f;
    }
}
