const MongoClient = require('mongodb').MongoClient;
const url = 'mongodb+srv://daniel:<db_password>@cluster0.xn7ryma.mongodb.net/';
const dbName = 'daniel';

class Product {
    constructor(id, name, age, weight) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.weight = weight;
    }

    calculateValue() {
        return this.age * this.weight; // Example logic
    }
}

class ProductModel {
    constructor() {
        this.client = new MongoClient(url, { useNewUrlParser: true, useUnifiedTopology: true });
        this.client.connect();
        this.db = this.client.db(dbName);
        this.collection = this.db.collection('products');
    }

    async saveProduct(product) {
        await this.collection.insertOne(product);
    }

    async getAllProducts() {
        return await this.collection.find({}).toArray();
    }

    async getProductById(id) {
        return await this.collection.findOne({ id: id });
    }
}

class ProductController {
    constructor(model) {
        this.model = model;
    }

    async createProduct(name, age, weight) {
        const id = Math.floor(Math.random() * 10000); // Generate a unique ID
        const product = new Product(id, name, age, weight);
        await this.model.saveProduct(product);
    }

    async listProducts() {
        return await this.model.getAllProducts();
    }

    async findProductById(id) {
        return await this.model.getProductById(id);
    }
}
