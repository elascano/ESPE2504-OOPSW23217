class picture:
    
    def __init__(self, id, name, quality, date = None):
        self.id = id
        self.name = name
        self.quality = quality  # Por ejemplo, "1920x1080"
        self.date = date_register or datetime.now()