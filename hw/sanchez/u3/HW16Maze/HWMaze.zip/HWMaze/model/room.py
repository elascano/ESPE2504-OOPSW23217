class Room:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.walls = {'N': True, 'S': True, 'E': True, 'W': True}
        self.visited = False

    def remove_wall(self, other, direction):
        opposites = {'N': 'S', 'S': 'N', 'E': 'W', 'W': 'E'}
        self.walls[direction] = False
        other.walls[opposites[direction]] = False