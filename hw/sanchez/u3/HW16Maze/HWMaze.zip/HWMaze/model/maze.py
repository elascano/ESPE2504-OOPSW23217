from model.room import Room

class Maze:
    def __init__(self, width, height):
        self.width = width
        self.height = height
        self.grid = [[Room(x, y) for x in range(width)] for y in range(height)]
        self.entrance = (0, 0)
        self.exit = (width - 1, height - 1)

    def get_room(self, x, y):
        return self.grid[y][x]