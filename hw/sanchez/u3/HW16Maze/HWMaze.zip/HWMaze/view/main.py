from model.maze import Maze
from controller.maze_generator import MazeGenerator
from controller.maze_view import MazeView

def main():
    width = int(input("Enter maze width: "))
    height = int(input("Enter maze height: "))

    maze = Maze(width, height)
    generator = MazeGenerator(maze)
    generator.generate()
    view = MazeView(maze)
    view.display()

if __name__ == "__main__":
    main()