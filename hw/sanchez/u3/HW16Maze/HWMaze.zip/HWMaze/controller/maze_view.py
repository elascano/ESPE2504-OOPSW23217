class MazeView:
    def __init__(self, maze):
        self.maze = maze

    def display(self):
        width, height = self.maze.width, self.maze.height
        grid = self.maze.grid

        print(' ' + '_' * (width * 2 - 1))
        for y in range(height):
            line = '|'
            for x in range(width):
                room = grid[y][x]
                if room.walls['S']:
                    line += '_'
                else:
                    line += ' '
                if room.walls['E']:
                    line += '|'
                else:
                    line += ' '
            print(line)