import random

class MazeGenerator:
    def __init__(self, maze):
        self.maze = maze

    def generate(self):
        stack = []
        start = self.maze.get_room(*self.maze.entrance)
        start.visited = True
        stack.append(start)

        while stack:
            current = stack[-1]
            neighbors = self._get_unvisited_neighbors(current)
            if neighbors:
                direction, neighbor = random.choice(neighbors)
                current.remove_wall(neighbor, direction)
                neighbor.visited = True
                stack.append(neighbor)
            else:
                stack.pop()

        # Ensure entrance and exit doors
        self.maze.get_room(*self.maze.entrance).walls['N'] = False
        self.maze.get_room(*self.maze.exit).walls['S'] = False

    def _get_unvisited_neighbors(self, room):
        directions = {'N': (0, -1), 'S': (0, 1), 'E': (1, 0), 'W': (-1, 0)}
        neighbors = []
        for dir, (dx, dy) in directions.items():
            nx, ny = room.x + dx, room.y + dy
            if 0 <= nx < self.maze.width and 0 <= ny < self.maze.height:
                neighbor = self.maze.get_room(nx, ny)
                if not neighbor.visited:
                    neighbors.append((dir, neighbor))
        return neighbors