//functions.h
#include "functions.c"

void imprimirArchivos();

void IniciarSesion();

void RegistroPadreFamilia();

void RegistrarPagos();

void buscarRepresentante();

void buscarPago();

void modificarPadreFamilia();


